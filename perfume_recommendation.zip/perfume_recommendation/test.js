 console.log(0/0);
 div { position:relative; }
 #cm { position:absolute; }
 .hc { width:200px; left:0; right:0; margin-left:auto; margin-right:auto; }
 .vc { height:40px; top: 0; bottom:0; margin-top:auto; margin-bottom:auto; }
